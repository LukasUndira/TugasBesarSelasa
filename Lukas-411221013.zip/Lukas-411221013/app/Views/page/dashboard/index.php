<?=$this->extend('components/main')?>
<?=$this->section('content')?>

<?=$this->endSection()?>